let PageBase=function(options){
  let defaultOptions={
     accountKey:"login.userInfo",
     loginUrl:"/pages/huiyuan/login"
  };
  defaultOptions=Object.assign(defaultOptions,options);
  this.login=function(data){
    let key=defaultOptions.accountKey;
    wx.setStorageSync(key,data);
    return this;
  };
  this.logout=function(){
    let key=defaultOptions.accountKey;
    wx.removeStorageSync(key);
    return this;
  };
  this.hasLogin=function(){
    let obj=this.getAccountInfo();
    for(var key in obj) {
      return true;
    }
    return false;
  };
  this.getAccountInfo=function(){
    let key=defaultOptions.accountKey;
    return wx.getStorageSync(key)||{};
  };
  this.checkLogin=function(){
    if(!this.hasLogin()){
      wx.navigateTo({url:defaultOptions.loginUrl});
      return;
    }
    let page=defaultOptions.page;
    if(page!=null){
      page.setData({
        userInfo:this.getAccountInfo()
      });
    }
  }
};

module.exports = PageBase;