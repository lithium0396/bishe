let defualtOptions={
   vdomHandlerName:"updateDom",
   vdomName:"name",
   debug:false
};
let createInputVDom = (options) => {
  options=Object.assign(defualtOptions,options);
  let page=options["page"];
  let vdomHandlerName=options["vdomHandlerName"];
  let vdomName=options["vdomName"];
  if (page[vdomHandlerName] != null)
    return;
  page[vdomHandlerName] = (e) => {
    let domFieldName = e.currentTarget.dataset[vdomName];
    let obj = {};
    obj[domFieldName] = e.detail.value;
    page.setData(obj);
    if(options.debug)
       console.log(domFieldName + "=" + page.data[domFieldName]);
  };
}
module.exports = {
  cretateInputDom: createInputVDom
};