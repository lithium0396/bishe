let promisify = (api) => {
  return (options, ...params) => {
    return new Promise((resolve, reject) => {
      api(Object.assign({}, options, {
        success: resolve,
        fail: reject
      }), ...params);
    });
  }
};
let hostHead = getApp().globalData.hostHead || "";
let count = 0;
let request = (params) => {
  count++;
  wx.showLoading({
    title: "加载中...",
    mask: true
  });
  //const baseUrl="http://localhost:8080/petmis";
  let url = params.url;
  if (!(url.startsWith("http://") || url.startsWith("https://")))
    url = hostHead + url;
  let header = {
    ...params.header
  };
  if (header["content-type"] == null)
    header["content-type"] = "application/x-www-form-urlencoded";
  Object.assign(params, ...params, {
    url: url,
    header: header
  });
  return new Promise((resolve, rejects) => {
    wx.request({
      ...params,
      url: url,
      success(result) {
        resolve(result);
      },
      fail(err) {
        rejects(err);
      },
      complete() {
        count--;
        if (count <= 0)
          wx.hideLoading();
      }
    })
  });
};

let doUpload = (params) => {
  if (params == null || params.files == null) {
    promisify(wx.showToast)({
      title: '参数异常',
      icon: "none",
      mask: true
    });
    return;
  }
  let page = params.page;
  let temfile = params.files;
  console.log("temfile",temfile);
  let url = params.url;
  console.log("page=", page);
  if (url == null)
    url = hostHead + "/admin/upload"
  else
  if (!(url.startsWith("http://") || url.startsWith("https://")))
    url = hostHead + url;
  return new Promise((resolve, reject) => {
    let urls = [];
    temfile.tempFilePaths.forEach(async (v, i) => {
      let res = await promisify(wx.uploadFile)({
        url: url,
        filePath: v,
        name: "file",
        formData: {}
      });
      res = JSON.parse(res.data);
      if (res.stateCode > 0) {
        if (res.data.length > 0) {
          urls.push(res.data[0].url);
          //page.data.files.push(res.data[0].url);
        }
        console.log("上传完成done");
        resolve({
          urls
        });
      }
    }); //end foreach
  });
}

let uploadFile = (params) => {
  if (params == null)
    return;
  let url = params.url;
  if (url == null)
    url = hostHead + "/admin/animal/identify"
  else
  if (!(url.startsWith("http://") || url.startsWith("https://")))
    url = hostHead + url;
  
  console.log("params=",params);
  return new Promise((resolve, rejects) => {
    wx.uploadFile({
      ...params,
      url:url,
      success(res) {
        resolve(res);
      },
      fail(err) {
        reject(err)
      }
    })

  });
};


module.exports = {
  login: promisify(wx.login),
  getSetting: promisify(wx.getSetting),
  getUserInfo: promisify(wx.getUserInfo),
  request: request,
  showToast: promisify(wx.showToast),
  showModal: promisify(wx.showModal),
  doUpload: doUpload,
  chooseImage: promisify(wx.chooseImage),
  uploadFile: uploadFile


}