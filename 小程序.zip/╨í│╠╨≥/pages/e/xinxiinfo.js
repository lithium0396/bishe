const wxPromisify = require("../../util/promisify");
var WxParse = require('../../wxParse/wxParse.js');
Page({

    /**
     * 页面的初始数据
     */
    data: {
        listComment: []
    },
    onShow: function() {
        console.log("页面显示");
        let pages = getCurrentPages();
        let currentPage = pages[pages.length - 1];
        let type = currentPage.options.type;
        let id = currentPage.options.id;
        this.setData({
            id: id
        });
        this.getInfo(type, id);
        this.getRelated(type, id);
    },

    async getCommentList(type, id) {
        let res = await wxPromisify.request({
            url: "/admin/comment/list",
            data: {
                type: type,
                belongid: id
            },
            method: 'POST'
        });
        console.log(res.data);
        if (res.data.stateCode < 0) {
            wxPromisify.showToast({
                title: res.data.des,
                icon: "none",
                mask: true
            });
            return;
        }
        res.data.data.forEach(v => {
            if (v.picarr != null)
                v.picarr = v.pics.split(";");
        });
        this.setData({
            listComment: res.data.data
        });

    },

    async getRelated(type, id) {
        let res = await wxPromisify.request({
            url: "/admin/xinxi/related",
            data: {
                type: type,
                id: id
            },
            method: 'GET'
        });
        console.log(res.data);
        if (res.data.stateCode < 0) {
            wxPromisify.showToast({
                title: res.data.des,
                icon: "none",
                mask: true
            });
            return;
        }

        this.setData({
            listRelated: res.data.data
        });

    },

    async getInfo(type, id) {
        let res = await wxPromisify.request({
            url: "/admin/lanmu/detail",
            data: {
                type,
                id
            },
            method: 'POST'
        });
        console.log(res.data);

        if (res.data.stateCode < 0) {
            wxPromisify.showToast({
                title: res.data.des,
                icon: "none",
                mask: true
            });
            return;
        }

        let hostHead = getApp().globalData.hostHead;
        let xinxi = res.data.data.info;
        if (xinxi.tupian != null && xinxi.tupian != "")
            xinxi.imgarr = xinxi.tupian.split(";");
        if (xinxi.imgarr != null) {
            for (var i = 0; i < xinxi.imgarr.length; i++) {
                xinxi.imgarr[i] = hostHead + xinxi.imgarr[i];
            }
        }
        this.setData({
            xinxi
        });
        WxParse.wxParse('xinxides', 'html', xinxi.des, this, 5);

    }

});