const wxPromisify = require("../../util/promisify");
import WxValidate from "../../util/WxValidate";
const HuiyuanFilter = require("../../util/pagebase");

Page({

    /**
     * 页面的初始数据
     */
    data: {

    },

    onShow() {
        let pages = getCurrentPages();
        let currentPage = pages[pages.length - 1];
        let type = currentPage.options.type;
        let id = currentPage.options.id;
        this.setData({
            id: id
        });
        this.getInfo();
    },
    async getInfo() {
        let res = await wxPromisify.request({
            url: "/admin/video/info",
            data: {
                id: this.data.id
            },
            method: 'POST'
        });
        console.log(res.data);
        if (res.data.stateCode < 0) {
            wxPromisify.showToast({
                title: res.data.des,
                icon: "none",
                mask: true
            });
            return;
        }
        let video = res.data.data;
        let hostHead = getApp().globalData.hostHead;
        if (video.tupian != null && video.tupian != "")
            video.imgarr = video.tupian.split(";");
        if (video.imgarr != null) {
            for (var i = 0; i < video.imgarr.length; i++) {
                video.imgarr[i] = hostHead + video.imgarr[i];
            }
        }
        if (video.url != null && !(video.url.startsWith("https://") || video.url.startsWith("http://"))) {
            video.url = hostHead + video.url;
        }

        this.setData({
            video
        });
    }


});