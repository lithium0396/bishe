const wxPromisify = require("../../util/promisify");
import WxValidate from "../../util/WxValidate";
const HuiyuanFilter = require("../../util/pagebase");
Page({

    /**
     * 页面的初始数据
     */
    data: {

    },
    onLoad(options) {
        this.getPapers();
        let hostHead = getApp().getHostHead();
        this.setData({ hostHead });
    },
    async getPapers() {
        let res = await wxPromisify.request({
            url: "/admin/shijuan/list",

            method: 'POST'
        });
        console.log(res.data);
        if (res.data.stateCode < 0) {
            wxPromisify.showToast({
                title: res.data.des,
                icon: "none",
                mask: true
            });
            return;
        }
        let listPaper = res.data.data;


        this.setData({
            listPaper
        });
    }

})