const HuiyuanFilter = require("../../util/pagebase");
const wxPromisify = require("../../util/promisify");

Page({

    data: {

    },
    onLoad: function(options) {

    },
    onChange(e) {
        this.setData({
            value: e.detail,
        });
    },
    onSearch() {
        let data = { name: this.data.value };
        this.getShangpins(data);
    },
    onClick() {
        let data = { name: this.data.value };
        this.getShangpins(data);
    },

    async getShangpins(data) {

        let res = await wxPromisify.request({
            url: "/admin/shangpin/list",
            data,
            method: "GET"
        });
        console.log(res.data);
        let hostHead = getApp().globalData.hostHead;
        let listShangpin = res.data.data;

        listShangpin.forEach(item => {
            let tupian = item.tupian;
            if (tupian != "" && tupian != null)
                item.imgarr = tupian.split(";");
            if (item.imgarr != null) {
                for (var i = 0; i < item.imgarr.length; i++) {
                    item.imgarr[i] = hostHead + item.imgarr[i];
                }
            }

        });
        this.setData({
            listShangpin: listShangpin
        });
    },

    /**
     * 页面上拉触底事件的处理函数
     */
    onReachBottom: function() {

    },

    /**
     * 用户点击右上角分享
     */
    onShareAppMessage: function() {

    }
})