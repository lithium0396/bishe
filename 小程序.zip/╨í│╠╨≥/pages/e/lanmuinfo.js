const wxPromisify = require("../../util/promisify");
Page({

    data: {

    },
    onShow() {
        let pages = getCurrentPages();
        let currentPage = pages[pages.length - 1];
        let lmId = currentPage.options.lmId;
        this.getLanmuContent(lmId);

    },
    async getLanmuContent(columnId) {
        let res = await wxPromisify.request({
            url: "/admin/lanmu/content/" + columnId,
            data: {
                type: 1
            },
            method: 'GET'
        });
        console.log(res.data);
        if (res.data.stateCode < 0) {
            wxPromisify.showToast({
                title: res.data.des,
                icon: "none",
                mask: true
            });
            return;
        }
        let lanmu = res.data.data;
        let hostHead = getApp().globalData.hostHead;
        lanmu.content.forEach(item => {
            let tupian = item.tupian;
            if (tupian != "" && tupian != null)
                item.imgarr = tupian.split(";");
            if (item.imgarr != null) {
                for (var i = 0; i < item.imgarr.length; i++) {
                    item.imgarr[i] = hostHead + item.imgarr[i];
                }
            }

        });
        this.setData({
            lanmu
        });
    },
    onReachBottom() {
        console.log("ReachBottom")
    }
});