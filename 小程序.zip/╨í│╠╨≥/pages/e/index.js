const wxPromisify = require("../../util/promisify");
Page({
    data: {
        listFocus: [],
        current: 0

    },
    swiperChange: function(e) {
        this.setData({
            current: e.detail.current,
        })
    },
    getFocus() {
        wxPromisify.request({
            url: "/admin/jdtmanager/list"
        }).then(res => {
            //let listFocus = res.data.data.map(v => v.tupian);
            let listFocus = res.data.data;
            this.setData({
                listFocus
            });
        });
    },
    onShow() {
        this.getFocus();
        this.getPageContent();
        this.getPapers();
        let hostHead = getApp().getHostHead();
        this.setData({ hostHead });

    },
    async getPageContent() {
        let res = await wxPromisify.request({
            url: "/admin/pagesetting/content/1",
            method: 'GET'
        });
        console.log(res.data);
        if (res.data.stateCode < 0) {
            wxPromisify.showToast({
                title: res.data.des,
                icon: "none",
                mask: true
            });
            return;
        }
        let hostHead = getApp().globalData.hostHead;
        let listLanmuContent = res.data.data.listLanmuContent;
        listLanmuContent.forEach(c => {
            c.content.forEach(item => {
                if (item.tupian != null && item.tupian != "")
                    item.imgarr = item.tupian.split(";");

                if (item.imgarr != null) {
                    for (var i = 0; i < item.imgarr.length; i++) {
                        item.imgarr[i] = hostHead + item.imgarr[i];
                    }
                }
            });
        });
        console.log(listLanmuContent);
        this.setData({
            pageContent: listLanmuContent
        });
    },
    async getPapers() {
        let res = await wxPromisify.request({
            url: "/admin/shijuan/list",

            method: 'POST'
        });
        console.log(res.data);
        if (res.data.stateCode < 0) {
            wxPromisify.showToast({
                title: res.data.des,
                icon: "none",
                mask: true
            });
            return;
        }
        let listPaper = res.data.data;
        this.setData({
            listPaper
        });
    }



});