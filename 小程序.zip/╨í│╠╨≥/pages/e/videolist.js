const wxPromisify = require("../../util/promisify");
import WxValidate from "../../util/WxValidate";
const HuiyuanFilter = require("../../util/pagebase");

Page({

    /**
     * 页面的初始数据
     */
    data: {

    },

    onLoad(options) {
        this.getList();
    },
    async getList() {
        let res = await wxPromisify.request({
            url: "/admin/video/list",
            method: 'POST'
        });
        console.log(res.data);
        if (res.data.stateCode < 0) {
            wxPromisify.showToast({
                title: res.data.des,
                icon: "none",
                mask: true
            });
            return;
        }
        let listVideo = res.data.data;
        let hostHead = getApp().globalData.hostHead;
        listVideo.forEach(item => {
            let tupian = item.tupian;
            if (tupian != "" && tupian != null)
                item.imgarr = tupian.split(";");
            if (item.imgarr != null) {
                for (var i = 0; i < item.imgarr.length; i++) {
                    item.imgarr[i] = hostHead + item.imgarr[i];
                }
            }
            if (item.url != null && !(item.url.startsWith("https://") || item.url.startsWith("http://"))) {
                item.url = hostHead + item.url;
            }

        });

        this.setData({
            listVideo
        });
    }


});