const wxPromisify = require("../../util/promisify");
import WxValidate from "../../util/WxValidate";
const PageBase = require("../../util/pagebase");
Page({


    data: {

    },
    onLoad(options) {
        let id = options.id;
        new PageBase({ page: this }).checkLogin();
        this.getPapaer(id);
    },
    async submitTest(e) {
        console.log(e.detail.value);
        let res = await wxPromisify.showModal({
            title: "系统提示",
            content: "确定要提交测试"
        });
        if (!res.confirm) {
            return;
        }
        let paper = this.data.paper;

        console.log("answers", this.data.answers);
        res = await wxPromisify.request({
            url: "/admin/shijuan/exam",
            data: {
                answers: this.data.answers,
                paperId: paper.id,
                paperName: paper.title,
                hyid: this.data.userInfo.id,
                hyName: this.data.userInfo.name
            },
            header: {
                "content-type": "application/json"
            },
            method: "POST"
        });
        console.log(res.data);
        wx.navigateTo({
            url: "/pages/huiyuan/dajuanmanager"
        });
    },
    async getPapaer(id) {
        let res = await wxPromisify.request({
            url: "/admin/shijuan/info",
            data: {
                id: id
            },
            method: 'POST'
        });
        console.log(res.data);
        this.setData({
            paper: res.data.data
        });
        this.initData();
    },
    initData() {
        let paper = this.data.paper;
        let paperModules = paper.paperModules;
        if (paperModules == null)
            return;
        let questions = [];
        let answers = [];

        if (paperModules.length <= 0)
            return;
        let index = 0;
        for (let key in paperModules) {
            let pm = paperModules[key];
            pm.questions.forEach(c => {
                c.qType = pm.type;
                c.sequence = index++;
                questions.push(c);
                answers.push({
                    hasDo: false,
                    id: c.id,
                    stdaan: c.daan,
                    fenshu: c.fenshu,
                    qType: c.qType
                });
            });
        }
        let curQuestion = questions[0];
        curQuestion.next = true;
        curQuestion.last = false;
        this.setData({
            curQuestion,
            questions,
            answers
        });
        //console.log("answers", this.data.answers);

    },
    getNextQuestion() {
        let curQuestion = this.data.curQuestion;
        let questions = this.data.questions;
        if (curQuestion == null || questions == null)
            return;
        let sequence = curQuestion.sequence;
        if (sequence < (questions.length - 1)) {
            sequence++;
        }
        curQuestion = questions[sequence];
        if (curQuestion.sequence >= (questions.length - 1)) {
            curQuestion.last = true;
            curQuestion.next = false;
        } else {
            curQuestion.last = true;
            curQuestion.next = true;
        }
        this.setData({
            curQuestion
        });
        console.log("curQuestion", curQuestion);
    },


    getLastQuestion() {
        let curQuestion = this.data.curQuestion;
        let questions = this.data.questions;
        if (curQuestion == null || questions == null)
            return;
        let sequence = curQuestion.sequence;
        if (sequence > 0) {
            sequence--;
        }
        curQuestion = questions[sequence];
        if (curQuestion.sequence <= 0) {
            curQuestion.last = false;
            curQuestion.next = true;
        } else {
            curQuestion.last = true;
            curQuestion.next = true;
        }
        this.setData({
            curQuestion
        });
        console.log("curQuestion", curQuestion);

    },

    nextQuestionClick(_e) {
        this.getNextQuestion();
        //console.log("点击下一个题");
    },
    lastQuestionClick(_e) {
        this.getLastQuestion();
        //console.log("点击上一题");
    },
    singleChoiceClick(e) {
        let result = e.detail.value;
        let id = e.currentTarget.dataset.id;
        this.answerQuestion(id, result, 1);
    },
    judgeClick(e) {

        let result = e.detail.value;
        let id = e.currentTarget.dataset.id;
        this.answerQuestion(id, result, 2);

    },
    tiankongOver(e) {
        let result = e.detail.value;
        let id = e.currentTarget.dataset.id;
        this.answerQuestion(id, result, 3);
    },
    jiandaOver(e) {
        let result = e.detail.value;
        let id = e.currentTarget.dataset.id;
        this.answerQuestion(id, result, 4);
    },
    answerQuestion(id, result, qType) {
        let sequence = this.data.curQuestion.sequence;
        let answers = this.data.answers;
        let questions = this.data.questions;
        answers[sequence] = {
            result,
            id,
            qType,
            fenshu: questions[sequence].fenshu,
            stdaan: questions[sequence].daan,
            hasDo: true
        };
        // console.log("answers", answers);
        this.setData({
            answers
        });
    },
    chooseQuestionClick(e) {
        let sequence = e.currentTarget.dataset.sequence;
        let questions = this.data.questions;
        if (questions == null)
            return;
        if (sequence < 0 || sequence > (questions.length - 1))
            return;
        let curQuestion = questions[sequence];
        if (curQuestion.sequence <= 0) {
            curQuestion.last = false;
            curQuestion.next = true;
        } else {
            if (curQuestion.sequence < (questions.length - 1)) {
                curQuestion.last = true;
                curQuestion.next = true;
            } else {
                curQuestion.last = true;
                curQuestion.next = false;
            }
        }
        this.setData({
            curQuestion
        });

    }





});