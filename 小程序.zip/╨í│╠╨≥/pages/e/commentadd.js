const wxPromisify=require("../../util/promisify");
const vdom=require("../../util/vdom");
const HuiyuanFilter=require("../../util/pagebase");
Page({

  data: {
    uploadedUrls: []
  },
  onLoad: function (options) {
      this.setData({
          uploadFile: this.uploadFile.bind(this),
          type:options.type,
          belongid:options.id
      })
      console.log("belongid="+this.data.belongid);
  },
  onShow(){
    vdom.cretateInputDom({
      page: this
    });
  },
  uploadFile(files) {
    return wxPromisify.doUpload({
        files:files,
        page:this
    });
  },
  deleteFile(e){
    console.log(e.detail);
    let index=e.detail.index;
    // let fileurls=this.data.fileurls.splice(index,1);
    // this.setData({
    //   fileurls
    // });
  },
  uploadError(e) {
      console.log('upload error', e.detail)
  },
  uploadSuccess(e) {
    console.log(e.detail);
    let urls= this.data.uploadedUrls;
    urls=urls.concat(e.detail.urls);
    this.setData({
      uploadedUrls:urls
    });
  },
 async submit(e){
     let filter=new HuiyuanFilter({page:this});
     let hasLogin=filter.hasLogin();
     if(!hasLogin){
       wx.navigatorTo({url:"/pages/huiyuan/login"});
       return;
     }
     if(this.data.dcontent==null||this.data.dcontent==""){
      wxPromisify.showToast({
         title:'请填写评论信息',
         icon:"none",
         mask:true
      }); 
      return;
     }
    let pics=this.data.uploadedUrls.join(";");
    console.log("pics="+pics);
    filter.checkLogin();
     let res=await wxPromisify.request({
       url:"/admin/comment/save",
       data:{
         dcontent:this.data.dcontent,
         pics:pics,
         type:this.data.type,
         belongid:this.data.belongid,
         commentor:this.data.userInfo.accountname
       },
       method:'POST'
     });
    console.log(res.data);
    wxPromisify.showToast({title:'评论成功'})
    .then(res=>{
         wx.redirectTo({
         url: '/pages/e/xinxiinfo?type=1&id='+this.data.belongid,
      });
    });
    //   
  }
  
})