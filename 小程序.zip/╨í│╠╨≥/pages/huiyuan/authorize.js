
Page({

  data: {

  },

  onLoad: function (options) {

  },
  authorize(e){
    console.log(e);
    wx.navigateBack({
      delta: 1
    });
  }

});