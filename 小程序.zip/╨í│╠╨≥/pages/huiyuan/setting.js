const PageBase =require("../../util/pagebase");
const wxPromisify=require("../../util/promisify");
Page({
  data: {
  },
  onShow: function (options) {
     new PageBase({page:this}).checkLogin();
  },
 async  btnExitClick(e){
    let res=await wxPromisify.showModal({
      title: '系统提示',
      content:"确定要退出"
    });
    if(res.confirm){
       new PageBase().logout().checkLogin();
    }
  }

});