const wxPromisify = require("../../util/promisify");
import WxValidate from "../../util/WxValidate";
const HuiyuanFilter = require("../../util/pagebase");
Page({
    data: {},
    onLoad(options) {
        let id = options.id;
        this.getPapaer(id);
    },
    async getPapaer(id) {
        let res = await wxPromisify.request({
            url: "/admin/dajuan/info",
            data: {
                id: id
            },
            method: 'POST'
        });
        console.log(res.data);
        this.setData({
            dajuan: res.data.data
        });

    }
});