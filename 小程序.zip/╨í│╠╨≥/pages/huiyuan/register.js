const wxPromisify = require("../../util/promisify");
const v2m = require("../../util/vdom");
import WxValidate from "../../util/WxValidate";
Page({
  data: {

  },
  onLoad: function (options) {
    this.initValidate();
  },
  async registerHandler(e) {
    let data = e.detail.value;
    if (!this.wxValidate.checkForm(data)) {
      const error = this.wxValidate.errorList[0]
      wxPromisify.showModal({
        content: error.msg,
        showCancel: false
      });
      return false
    }
    data.accountname=data.mobile;
    let res = await wxPromisify.request({
      url: "/admin/huiyuanmanager/register",
      data: data,
      method: 'POST'
    });
    //注册成功
    if (res.data.stateCode <0) {
      wxPromisify.showToast({
        title:"账户已经存在"
      });
      return;
    } //end if

    wxPromisify.showToast({
      title: "账户注册成功",
      mask: true,
      icon: "success",
    });
    wx.navigateTo({
      url:"/pages/huiyuan/login",
    });
    
  },
  initValidate() {
    const rules = {

      mobile: {
        required: true,
        tel: true
      },
      password: {
        required: true
      },
      password2: {
        required: true,
        equalTo:"password"
      },
      name: {
        required: true
      },
      agree:{
        required:true
      }
    };
    const messages = {
      mobile: {
        required: "请输入电话号码",
        tel: "请输入正确电话号码"
      },
      password: {
        required: "请输入密码"
      },
      password2: {
        required: "请输入确认密码",
        equalTo:"两次密码不一致"
      },
      name: {
        required: "请输入姓名"
      },
      agree:{
        required:"请同意协议"
      }
    };
    this.wxValidate = new WxValidate(rules, messages);
  },

});