const wxPromisify =require("../../util/promisify");
const PageBase =require("../../util/pagebase")
Page({
  data: {
   
  },
  onShow() {
    new PageBase({
      page:this
    }).checkLogin();
    this.setData({
      ...this.data.userInfo
    });
  }
  
});