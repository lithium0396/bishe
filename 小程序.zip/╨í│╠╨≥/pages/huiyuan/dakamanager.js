const wxPromisify = require("../../util/promisify");
import WxValidate from "../../util/WxValidate";
const HuiyuanFilter = require("../../util/pagebase");
Page({

    /**
     * 页面的初始数据
     */
    data: {

    },
    onLoad(options) {

        new HuiyuanFilter({ page: this }).checkLogin();
        this.setData({
            hyid: this.data.userInfo.id
        });
        this.list();
    },
    async list() {

        let res = await wxPromisify.request({
            url: "/admin/daka/list",
            data: {
                hyid: this.data.hyid
            },
            method: 'POST'
        });
        console.log(res.data);
        if (res.data.stateCode < 0) {
            wxPromisify.showToast({
                title: res.data.des,
                icon: "none",
                mask: true
            });
            return;
        }
        let listDaka = res.data.data;
        this.setData({
            listDaka
        });
    },
    async delete(e) {

        let id = e.currentTarget.dataset.id;

        let res = await wxPromisify.showModal({
            title: "系统提示",
            content: "确定要删除"
        });
        if (!res.confirm) {
            return;
        }
        res = await wxPromisify.request({
            url: "/admin/daka/delete",
            data: {
                id
            },
            method: 'POST'
        });
        if (res.data.stateCode > 0) {
            this.list();
            wxPromisify.showToast({ title: "删除成功", icon: "success", mask: true });
        }


    }

})