const wxPromisify = require("../../util/promisify");
const PageBase = require("../../util/pagebase")
import WxValidate from "../../util/WxValidate";

Page({

    /**
     * 页面的初始数据
     */
    data: {

    },
    onLoad() {
        new PageBase({
            page: this
        }).checkLogin();
        this.initValidate();
        console.log(this.data.userInfo);
    },
    async submitHandler(e) {
        let data = e.detail.value;
        if (!this.wxValidate.checkForm(data)) {
            const error = this.wxValidate.errorList[0]
            wxPromisify.showModal({
                content: error.msg,
                showCancel: false
            });
            return false
        }
        data.id = this.data.userInfo.id;
        let res = await wxPromisify.request({
            url: "/admin/huiyuan/chongzhi",
            data,
            method: 'POST'
        });
        console.log(res.data);
        new PageBase({
            page: this
        }).login(res.data.data);
        wxPromisify.showToast({
            title: '充值成功'
        }).then(res => {
            wx.redirectTo({
                url: "/pages/huiyuan/yue",
            });
        });
    },
    initValidate() {
        let rules = {
            fee: {
                required: true,
                digits: true
            },

        };
        let messages = {
            fee: {
                required: '请输入充值金额',
                digits: '请输入正确的金额'
            }

        };
        this.wxValidate = new WxValidate(rules, messages);
    }


})