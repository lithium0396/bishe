const wxPromisify = require("../../util/promisify");
import WxValidate from "../../util/WxValidate";
const HuiyuanFilter = require("../../util/pagebase");
Page({

    /**
     * 页面的初始数据
     */
    data: {

    },
    onLoad(options) {

        new HuiyuanFilter({ page: this }).checkLogin();

        this.getDajuans();
    },
    async getDajuans() {

        let res = await wxPromisify.request({
            url: "/admin/dajuan/list",
            data: {
                testerid: this.data.userInfo.id
            },
            method: 'POST'
        });
        console.log(res.data);
        if (res.data.stateCode < 0) {
            wxPromisify.showToast({
                title: res.data.des,
                icon: "none",
                mask: true
            });
            return;
        }
        let listDajuan = res.data.data;
        this.setData({
            listDajuan
        });
    },
    async delete(e) {

        let id = e.currentTarget.dataset.id;

        let res = await wxPromisify.showModal({
            title: "系统提示",
            content: "确定要删除"
        });
        if (!res.confirm) {
            return;
        }
        res = await wxPromisify.request({
            url: "/admin/dajuan/delete",
            data: {
                id
            },
            method: 'POST'
        });
        if (res.data.stateCode > 0) {
            this.getDajuans();
            wxPromisify.showToast({ title: "删除成功", icon: "success", mask: true });
        }


    }

})