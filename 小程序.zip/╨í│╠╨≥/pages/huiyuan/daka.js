const wxPromisify = require("../../util/promisify");
import WxValidate from "../../util/WxValidate";
const HuiyuanFilter = require("../../util/pagebase");

Page({

    /**
     * 页面的初始数据
     */
    data: {

    },

    onLoad(options) {
        new HuiyuanFilter({ page: this }).checkLogin();
    },
    onShow() {
        this.startTime();
    },
    async dakaClick() {

        let dkdate = this.dateFormat("YYYY-mm-dd", new Date());

        let res = await wxPromisify.request({
            url: "/admin/daka/save",
            data: {
                hyid: this.data.userInfo.id,
                hyname: this.data.userInfo.name,
                dkdate: dkdate
            },
            method: 'POST'
        });
        if (res.data.stateCode < 0) {
            wxPromisify.showToast({ title: res.data.des, icon: "none", mask: true });
            return;
        }
        wxPromisify.showToast({ title: "打卡成功", icon: "success", mask: true });
    },
    dateFormat(fmt, date) {
        let ret;
        const opt = {
            "Y+": date.getFullYear().toString(), // 年
            "m+": (date.getMonth() + 1).toString(), // 月
            "d+": date.getDate().toString(), // 日
            "H+": date.getHours().toString(), // 时
            "M+": date.getMinutes().toString(), // 分
            "S+": date.getSeconds().toString() // 秒
                // 有其他格式化字符需求可以继续添加，必须转化成字符串
        };
        for (let k in opt) {
            ret = new RegExp("(" + k + ")").exec(fmt);
            if (ret) {
                fmt = fmt.replace(ret[1], (ret[1].length == 1) ? (opt[k]) : (opt[k].padStart(ret[1].length, "0")))
            };
        };
        return fmt;
    },

    startTime: function() {
        var today = new Date();
        var month = today.getMonth();
        var day = today.getDate();
        var week = today.getDay();
        var h = today.getHours();
        var m = today.getMinutes();
        var s = today.getSeconds(); // 在小于10的数字钱前加一个‘0’
        month = this.formatTime(month);
        day = this.formatTime(day);
        m = this.formatTime(m);
        s = this.formatTime(s);


        this.setData({
            hours: h,
            minutes: m,
            seconds: s,
            month: this.translateMonth(month),
            day: day,
            week: this.translateWeek(week)
        })
        var t = setTimeout(() => { this.startTime() }, 500);
    },

    formatTime: function(i) {
        if (i < 10) {
            i = "0" + i;
        }
        return i;
    },
    translateMonth(month) {
        month = month * 1 + 1
        if (month < 10) {
            return month = '0' + month
        } else
            return month = month + ''
    },
    translateWeek(week) {
        switch (week) {
            case 0:
                return '星期日';
            case 1:
                return '星期一';
            case 2:
                return '星期二';
            case 3:
                return '星期三';
            case 4:
                return '星期四';
            case 5:
                return '星期五';
            case 6:
                return '星期六';
            default:
        }
    }


});