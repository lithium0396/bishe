const wxPromisify = require("../../util/promisify");
const PageBase = require("../../util/pagebase")
Page({

    /**
     * 页面的初始数据
     */
    data: {

    },
    onLoad(options) {

    },
    onShow() {
        new PageBase({
            page: this
        }).checkLogin();
        console.log(this.data.userInfo);
    }
})