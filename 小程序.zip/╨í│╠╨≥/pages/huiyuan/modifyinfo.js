const wxPromisify =require("../../util/promisify");
const PageBase =require("../../util/pagebase")
Page({
  data: {
   
  },
  onShow() {
    new PageBase({
      page:this
    }).checkLogin();
    this.setData({
      ...this.data.userInfo
    });

  },
  //更新账户信息
  async submitHandler(e){
     let mobile=this.data.mobile;
     let des=this.data.des;
     let name=this.data.name;
     let sex=this.data.sex;
     let res=await wxPromisify.request({
       url:"/admin/huiyuanmanager/modifyinfo",
       data:{
         accountname:this.data.userInfo.accountname,
         name:name,
         mobile:mobile,
         sex:sex,
         des:des
       },
       method:'POST'
     });
     if(res.data.stateCode<0){
       wxPromisify.showToast({title:res.data.des,icon:"none",mask:true});
       return;
     }
     new PageBase().login(res.data.data);
     wxPromisify.showToast({title:"账户修改成功",icon:"none",mask:true});
  },
  sexClick(event) {
    const { key } = event.currentTarget.dataset;
    this.setData({ [key]: event.detail });
  },
});