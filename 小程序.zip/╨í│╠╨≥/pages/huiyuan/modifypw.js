const wxPromisify =require("../../util/promisify");
const PageBase =require("../../util/pagebase")
Page({
  data: {
   
  },
  onShow() {
    new PageBase({
      page:this
    }).checkLogin();
  },
  async submitHandler(e){
     let oldpwd=this.data.oldpwd;
     let newpwd=this.data.newpwd;
     let newpwd2=this.data.newpwd2;
     if(oldpwd==null||oldpwd==""){
        wxPromisify.showToast({title:"请输入原始密码",icon:"none",mask:true});
        return;
     }
    if(newpwd==null||newpwd==""){
      wxPromisify.showToast({title:"请输入新密码",icon:"none",mask:true});
      return;
     }
   if(newpwd2==null||newpwd2==""){
    wxPromisify.showToast({title:"请输入确定密码",icon:"none",mask:true});
    return;
   }
   if(newpwd!=newpwd2){
       wxPromisify.showToast({title:"两次密码输入不一致",icon:"none",mask:true});
       return;
     }
     let res=await wxPromisify.request({
       url:"/admin/huiyuanmanager/modifypwd",
       data:{
         accountname:this.data.userInfo.accountname,
         newpwd:newpwd,
         oldpwd:oldpwd
       },
       method:'POST'
     });
     if(res.data.stateCode<0){
       wxPromisify.showToast({title:res.data.des,icon:"none",mask:true});
       return;
     }
     wxPromisify.showToast({title:"密码修改成功",icon:"none",mask:true});
  }
});