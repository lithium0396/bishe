const wxPromisify = require("../../util/promisify");
const vdom = require("../../util/vdom");
const HuiyuanFilter = require("../../util/pagebase");

Page({
    data: {},
    onLoad() {
        vdom.cretateInputDom({
            page: this
        });
    },

    //微信方式登录
    async wxLoginHandler(e) {
        let res = await wxPromisify.getSetting();
        if (!res.authSetting['scope.userInfo']) {
            await wx.navigateTo({
                url: "/pages/huiyuan/authorize"
            });
            return;
        }
        res = await wxPromisify.login();
        let code = res.code;
        let userInfo = {};
        res = await wxPromisify.request({
            url: "/admin/systemcfg/openid",
            data: {
                code: code
            },
            method: "POST"
        });
        userInfo.openid = res.data.data.openid;
        res = await wxPromisify.getUserInfo();
        Object.assign(userInfo, res.userInfo);
        console.log("微信账户信息", userInfo);
        res = await wxPromisify.request({
            url: "/admin/huiyuanmanager/wxlogin",
            data: {
                accountname: userInfo.openid,
                name: userInfo.nickName,
                sex: userInfo.gener == 1 ? "男" : "女",
                touxiang: userInfo.avatarUrl
            },
            method: "POST"
        });
        console.log(res);
        if (res.data.stateCode > 0) {
            new HuiyuanFilter({ page: this }).login(res.data.data);
            wx.switchTab({ url: "/pages/huiyuan/index" });
        }


    },
    //用户登录
    loginHandler(e) {
        let username = this.data.username;
        let password = this.data.password;
        if (username == null || username == "") {
            wxPromisify.showToast({
                title: "请输入用户名",
                icon: "none"
            });
            return;
        }
        if (password == null || password == "") {
            wxPromisify.showToast({
                title: "请输入密码",
                icon: "none"
            });
            return;
        }
        wxPromisify.request({
            url: "/admin/huiyuanmanager/login",
            data: {
                accountname: username,
                password: password
            },
            method: 'POST'
        }).then(res => {
            let data = res.data;
            if (data.stateCode == null) {
                wxPromisify.showToast({
                    title: "接口异常",
                    icon: "none",
                    mask: true
                });
                return;
            }
            if (data.stateCode < 0) {
                wxPromisify.showToast({
                    title: data.des
                });
                return;
            }
            new HuiyuanFilter({ page: this }).login(data.data);
            //getApp().login(data.data);
            wx.switchTab({
                url: "/pages/huiyuan/index"
            });
        }); //end request

    }

});