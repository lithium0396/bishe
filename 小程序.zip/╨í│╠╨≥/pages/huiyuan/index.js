const PageBase =require("../../util/pagebase");
Page({
  data: {
    userInfo:null
  },
  onShow:function () {
    new PageBase({
      page:this
    }).checkLogin();
  }
});