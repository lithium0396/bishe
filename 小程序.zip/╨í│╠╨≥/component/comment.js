const wxPromisify = require("../util/promisify");
const HuiyuanFilter = require("../util/pagebase");
Component({

    properties: {
        type: {
            type: String,
            value: 1
        },
        targetid: {
            type: String,
            value: 1
        }
    },
    data: {
        listComment: [],
        accountInfo: {}
    },
    async ready(e) {
        console.log("this.data.targetid" + this.data.targetid);
        console.log("this.data.type" + this.data.type);
        let accountInfo = new HuiyuanFilter({ page: this }).getAccountInfo();
        this.setData({
            accountInfo
        });
        await this.init();

    },
    pageLifetimes: {},
    methods: {
        async init() {
            let res = await wxPromisify.request({
                url: "/admin/comment/list",
                data: {
                    type: this.data.type,
                    belongid: this.data.targetid
                },
                method: 'POST'
            });
            console.log(res.data);
            if (res.data.stateCode < 0) {
                wxPromisify.showToast({
                    title: res.data.des,
                    icon: "none",
                    mask: true
                });
                return;
            }
            let hostHead = getApp().globalData.hostHead;
            res.data.data.forEach(item => {
                if (item.touxiang != null && !(item.touxiang.startsWith("http://") || item.touxiang.startsWith("https://")))
                    item.touxiang = hostHead + item.touxiang;
            });
            this.setData({
                listComment: res.data.data
            });
        }, //end init
        async deleteComment(e) {
            //评论编号 
            let id = e.currentTarget.dataset.id;
            let res = await wxPromisify.showModal({
                title: "系统提示",
                content: "确定要删除"
            });
            if (!res.confirm) {
                return;
            }
            res = await wxPromisify.request({
                url: "/admin/comment/delete",
                data: {
                    id: id
                },
                method: 'POST'
            });
            console.log(res.data);
            if (res.data.stateCode < 0) {
                wxPromisify.showToast({
                    title: res.data.des,
                    icon: "none",
                    mask: true
                });
                return;
            }
            this.init();

        }
    }

});