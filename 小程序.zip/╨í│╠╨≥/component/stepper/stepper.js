Component({
  properties: {
    key:{
      type:String,
      value:""
    },
    val:{
      type:String,
      value:1
    }
  },
  data: {
    // val: 1,
    // 使用data数据对象设置样式名
    minusStatus: 'disabled'
  },
  methods: {
    // 这里放置自定义方法
    /* 点击减号 */
    bindMinus: function () {
      var val = this.data.val;
      if (val <= 1) {
        return;
      }
      val--;
      // 只有大于一件的时候，才能normal状态，否则disable状态
      var minusStatus = val <= 1 ? 'disabled' : 'normal';
      // 将数值与状态写回
      this.setData({
        val: val,
        minusStatus: minusStatus
      });
      this.triggerEvent("countChange",{val:val,key:this.properties.key}); 
     
    },
    /* 点击加号 */
    bindPlus: function () {
      var val = this.data.val;
      val++;
      // 只有大于一件的时候，才能normal状态，否则disable状态
      var minusStatus = val < 1 ? 'disabled' : 'normal';
      // 将数值与状态写回
      this.setData({
        val: val,
        minusStatus: minusStatus
      });
      this.triggerEvent("countChange",{val:val,key:this.properties.key}); 
     
    },
    /* 输入框事件 */
    bindManual: function (e) {
      var val = e.detail.value;
      if(val<=1)
         val=1;
      this.setData({
        val: val
      });
      this.triggerEvent("countChange",{val:val,key:this.properties.key}); 
     
    }
  }
});