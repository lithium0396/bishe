App({

    globalData: {
        shopcartName: "shopcart",
        hostHead: "http://localhost:8080/exammis"
    },
    getHostHead() {
        return this.globalData.hostHead;
    }
});